hc-sr04
=======

HC-SR04 Ultrasonic Sensor Module - Energia C++ Class Library


INSTALLATION
============

Copy the hc-sr04 folder from within this repo to your Energia libraries folder.


